const Discord = require('discord.js-selfbot-v13');
const client = new Discord.Client({
  readyStatus: false,
  checkUpdate: false
});
const keepAlive = require('./server.js');
keepAlive();
function formatTime() {
  const date = new Date();
  const options = {
    timeZone: 'Africa/Casablanca',
    hour12: false,
    hour: 'numeric',
    minute: 'numeric'
  };
  return new Intl.DateTimeFormat('en-US', options).format(date);
}
client.on('ready', async () => {
  console.clear();
  console.log(`${client.user.tag} - Rich Presence started securely!`);
  const r = new Discord.RichPresence()
    .setApplicationId('Account_ID') // أيدي الحساب
    .setType('STREAMING')
    .setURL('https://www.twitch.tv/vir_bon')
    .setState('Devloped by VirBon 91')
    .setName('VirBon') 
    .setDetails(`4MZ Hub the best`)
    .setStartTimestamp(Date.now())
    .setAssetsLargeImage('https://cdn.discordapp.com/emojis/1365447064724705415.webp?size=96')
    .setAssetsLargeText('4MZ Hub')
    .setAssetsSmallImage('https://cdn.discordapp.com/emojis/1459896061266100428.webp?size=96&animated=true')
    .setAssetsSmallText('By VirBon 91')
    .addButton('YouTube', 'https://www.youtube.com/@VirBon91')
    .addButton('4MZ Hub', 'https://discord.gg/pSU8D9pDhM');
  client.user.setActivity(r);
  client.user.setPresence({ status: "dnd" });
  let prevTime = null;
  setInterval(() => {
    const VirBonTime = formatTime();
    if (VirBonTime !== prevTime) {
      const newDetails = `4MZ Hub the best | ${VirBonTime}`;
      r.setDetails(newDetails);
      client.user.setActivity(r);
      prevTime = VirBonTime;
    }
  }, 5000);
});


client.login("Account_Token"); // توكن الحساب

// YouTube: https://www.youtube.com/@VirBon91
// 4MZ Hub: https://discord.gg/pSU8D9pDhM